package com.shoppingManagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShoppingManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShoppingManagementApplication.class, args);
	}

}
